@extends('layouts.app')

@section('title', 'Contact')

@section('content')
<h1>contact page</h1>
@endsection